package helper;

import java.util.List;

import FineCheck.Fine;
import LibraryItem.Book;
import LibraryItem.LibraryItem;
import Transaction.BorrowRecord;
import User.PublicMember;
import User.User;

// MenuHelper - Handles all menu displays
public class MenuHelper {
    
    private static final String LINE = "========================================================================================================================";
    private static final String SHORT_LINE = "========================================";
    
    // Print header
    public static void printHeader(String title) {
        System.out.println("\n" + title);
        System.out.println(LINE);
    }
    
    public static void printSubHeader(String title) {
        System.out.println("\n" + title);
        System.out.println(LINE);
    }
    
    // Login and register titles
    public static void showLoginTitle() {
        System.out.println("\nLOGIN");
        System.out.println(LINE);
    }
    
    public static void showRegisterTitle() {
        System.out.println("\nREGISTER");
        System.out.println(LINE);
    }
    
    // Main menus
    public static void showLoginMenu() {
        System.out.println("\nLOGIN MENU");
        System.out.println(LINE);
        System.out.println("1. Login");
        System.out.println("2. Register");
        System.out.println("3. Continue as Guest");
        System.out.println("0. Exit");
        System.out.print("Choice: ");
    }
    
    public static void showStaffMenu() {
        System.out.println("\nSTAFF MENU");
        System.out.println(LINE);
        System.out.println("1. Items Management");
        System.out.println("2. Users Management");
        System.out.println("3. Borrows Management");
        System.out.println("4. Fines Management");
        System.out.println("0. Logout");
        System.out.print("Choice: ");
    }
    
    // User menu (different for Public vs Regular)
    public static void showUserMenu(boolean isPublicMember) {
        System.out.println("\n===================================");
        if (isPublicMember) {
            System.out.println("           PUBLIC MENU");
        } else {
            System.out.println("             USER MENU");
        }
        System.out.println("===================================");
        System.out.println("1. View Books");
        
        if (!isPublicMember) {
            System.out.println("2. My Borrows");
            System.out.println("3. My Fines");
        }
        
        System.out.println("0. Logout");
        System.out.print("Choice: ");
    }
    
    public static void showPublicMenu() {
        System.out.println("\nPUBLIC MENU");
        System.out.println(LINE);
        System.out.println("1. View Books");
        System.out.println("0. Logout");
        System.out.print("Choice: ");
    }
    
    // Sub menus
    public static void showItemsSubMenu() {
        System.out.println("\nITEMS MANAGEMENT");
        System.out.println(LINE);
        System.out.println("1. Add Item");
        System.out.println("2. Update Item");
        System.out.println("3. Delete Item");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    public static void showUsersSubMenu() {
        System.out.println("\nUSERS MANAGEMENT");
        System.out.println(LINE);
        System.out.println("1. Update User");
        System.out.println("2. Delete User");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    public static void showBorrowsSubMenu() {
        System.out.println("\nBORROWS MANAGEMENT");
        System.out.println(LINE);
        System.out.println("1. Mark Returned Item as Damaged/Lost");
        System.out.println("2. Delete Record");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    public static void showFinesSubMenu() {
        System.out.println("\nFINES MANAGEMENT");
        System.out.println(LINE);
        System.out.println("1. Update Fine");
        System.out.println("2. Delete Fine");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    public static void showBooksSubMenu() {
        System.out.println("\nBOOKS MENU");
        System.out.println(LINE);
        System.out.println("1. Borrow Item");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    public static void showMyBorrowsSubMenu() {
        System.out.println("\nMY BORROWS");
        System.out.println(LINE);
        System.out.println("1. Return Item");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    public static void showMyFinesSubMenu() {
        System.out.println("\nMY FINES");
        System.out.println(LINE);
        System.out.println("1. Pay Fine");
        System.out.println("0. Back");
        System.out.print("Choice: ");
    }
    
    // Add item headers
    public static void showAddItemHeader() {
        System.out.println("\nADD NEW ITEM");
        System.out.println(SHORT_LINE);
    }
    
    // Current info display
    public static void showCurrentItemInfo(LibraryItem item) {
        System.out.println("\nCURRENT ITEM INFO");
        System.out.println(SHORT_LINE);
        System.out.println("ISBN: " + item.getIsbn());
        System.out.println("Title: " + item.getTitle());
        System.out.println("Author: " + item.getAuthor());
        System.out.println("Genre: " + item.getGenre());
        System.out.println("Status: " + item.getStatus());
        if (item instanceof Book) {
            System.out.println("Page Count: " + ((Book) item).getPageCount());
        }
        System.out.println(SHORT_LINE);
    }
    
    public static void showCurrentUserInfo(User user) {
        System.out.println("\nCURRENT USER INFO");
        System.out.println(SHORT_LINE);
        System.out.println("User ID: " + user.getUserId());
        System.out.println("Username: " + user.getUsername());
        System.out.println("Email: " + (user.getEmail() == null ? "none" : user.getEmail()));
        System.out.println("Phone: " + (user.getPhone() == null ? "none" : user.getPhone()));
    }
    
    public static void showCurrentFineInfo(Fine fine) {
        System.out.println("\nCURRENT FINE INFO");
        System.out.println(SHORT_LINE);
        System.out.println("Fine ID: " + fine.getFineId());
        System.out.println("User ID: " + fine.getUserId());
        System.out.println("Amount: RM" + String.format("%.2f", fine.getAmount()));
        System.out.println("Status: " + fine.getStatus());
        System.out.println(SHORT_LINE);
    }
    
    // Update prompts
    public static void promptNewUsername(String current) {
        System.out.print("New Username (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewEmail(String current) {
        System.out.print("New Email (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewPhone(String current) {
        System.out.print("New Phone (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewPassword() {
        System.out.print("New Password (Enter to keep): ");
    }
    
    public static void promptNewMajor(String current) {
        System.out.print("New Major (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewDepartment(String current) {
        System.out.print("New Department (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewPosition(String current) {
        System.out.print("New Position (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewTitle(String current) {
        System.out.print("New Title (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewAuthor(String current) {
        System.out.print("New Author (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewGenre(String current) {
        System.out.print("New Genre (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewPageCount(int current) {
        System.out.print("New Page Count (Enter to keep: " + current + "): ");
    }
    
    public static void promptNewAmount(double current) {
        System.out.print("New Amount (Enter to keep: RM" + String.format("%.2f", current) + "): ");
    }
    
    public static void promptNewStatus(String current) {
        System.out.print("Status (Unpaid/Paid) (Enter to keep: " + current + "): ");
    }
    
    // Update status menu
    public static void showUpdateStatusMenu() {
        System.out.println("\nUpdate Status?");
        System.out.println("1. Available");
        System.out.println("2. Damaged");
        System.out.println("3. Lost");
        System.out.println("0. Skip");
        System.out.print("Choice: ");
    }
    
    // Delete confirmation
    public static void showDeleteConfirmation(String itemName) {
        System.out.println("\nDelete record: " + itemName);
        System.out.print("Confirm? (y/n): ");
    }
    
    public static void showDeleteItemConfirmation(String title) {
        System.out.println("\nAre you sure you want to delete: " + title + "?");
        System.out.print("Confirm (y/n): ");
    }
    
    public static void showDeleteUserConfirmation(String username) {
        System.out.println("\nAre you sure you want to delete: " + username + "?");
        System.out.print("Confirm (y/n): ");
    }
    
    public static void showDeleteFineConfirmation(String fineId) {
        System.out.println("\nDelete fine: " + fineId + "?");
        System.out.print("Confirm (y/n): ");
    }
    
    // Return condition menu
    public static void showReturnConditionMenu() {
        System.out.println("\nRETURN CONDITION");
        System.out.println("1. Damaged (RM25)");
        System.out.println("2. Lost (RM60)");
        System.out.print("Choice: ");
    }
    
    // Select record prompts
    public static void promptSelectRecordToReturn(int size) {
        System.out.println("\nSelect record to return:");
        System.out.print("Enter number (1-" + size + "): ");
    }
    
    public static void promptSelectRecordToDelete(int size) {
        System.out.println("\nSelect record to delete:");
        System.out.print("Enter number (1-" + size + "): ");
        
    }
    
    public static void promptSelectRecordToForceReturn(int size) {
        System.out.println("\nSelect record to force return:");
        System.out.print("Enter number (1-" + size + "): ");
    }
    
    public static void promptSelectFineToPay(int size) {
        System.out.println("\nSelect fine to pay:");
        System.out.print("Enter number (1-" + size + "): ");
    }
    
    // Display tables
    public static void displayItems(List<LibraryItem> items) {
        if (items.isEmpty()) {
            System.out.println("No items found!");
            return;
        }
        System.out.println("\nCATALOG");
        System.out.println(LINE);
        for (LibraryItem item : items) {
            System.out.println(item.toString());
        }
        System.out.println(LINE);
    }
    
public static void displayUsers(List<User> users, boolean showPublicOnly) {
    if (users.isEmpty()) {
        System.out.println("No users found!");
        return;
    }
    
    if (showPublicOnly) {
        System.out.println("\nPUBLIC");
        System.out.println(LINE);
        System.out.printf("%-10s | %-15s | %-10s | %-22s | %-13s| %-15s\n", 
            "ID", "USERNAME", "ROLE", "EMAIL", "PHONE", "INFO");
        System.out.println(LINE);
        for (User user : users) {
            if (user instanceof PublicMember) {
                System.out.println(user.toString());
            }
        }
        System.out.println(LINE);
    } else {
        System.out.println("\nUSER");
        System.out.println(LINE);
        System.out.printf("%-10s | %-15s | %-10s | %-22s | %-12s | %-15s | %-18s\n", 
            "ID", "USERNAME", "ROLE", "EMAIL", "PHONE", "LOGIN ID", "MAJOR/DEPT/POS");
        System.out.println(LINE);
        for (User user : users) {
            if (!(user instanceof PublicMember)) {
                System.out.println(user.toString());
            }
        }
        System.out.println(LINE);
    }
}
    
    public static void displayAllBorrowRecords(List<BorrowRecord> records) {
        if (records.isEmpty()) {
            System.out.println("No borrow records found!");
            return;
        }
        System.out.println("\nALL BORROW RECORDS");
        System.out.println(LINE);
        for (BorrowRecord record : records) {
            System.out.println(record.toString());
        }
        System.out.println(LINE);
    }
    
    public static void displayFines(List<Fine> fines) {
        if (fines.isEmpty()) {
            System.out.println("No fines found!");
            return;
        }
        System.out.println("\nFINES");
        System.out.println(LINE);
        for (Fine fine : fines) {
            System.out.println(fine.toString());
        }
        System.out.println(LINE);
    }
    
    // Active borrows display with numbers
    public static void displayActiveBorrowsWithNumbers(List<BorrowRecord> records) {
        if (records.isEmpty()) {
            System.out.println("No active borrow records!");
            return;
        }
        System.out.println("\nActive Borrow Records:");
        for (int i = 0; i < records.size(); i++) {
            BorrowRecord record = records.get(i);
            String status = record.isOverdue() ? "OVERDUE" : "BORROWED";
            System.out.println((i+1) + ". [" + status + "] " + record.getRecordId() + " - " + record.getItemTitle());
        }
    }
    
    // User borrows display with numbers
    public static void displayUserBorrowsWithNumbers(List<BorrowRecord> records) {
        if (records.isEmpty()) {
            System.out.println("No borrow records to return!");
            return;
        }
        System.out.println("\nSelect record to return:");
        for (int i = 0; i < records.size(); i++) {
            BorrowRecord record = records.get(i);
            String status = record.isOverdue() ? "OVERDUE" : "BORROWED";
            System.out.println((i+1) + ". [" + status + "] " + record.getRecordId() + " - " + record.getItemTitle());
        }
    }
    
    // Returned records display
    public static void displayReturnedRecordsWithNumbers(List<BorrowRecord> records) {
        if (records.isEmpty()) {
            System.out.println("No returned records to mark as damaged/lost!");
            return;
        }
        System.out.println("\nSelect returned record to mark as damaged/lost:");
        for (int i = 0; i < records.size(); i++) {
            BorrowRecord record = records.get(i);
            System.out.println((i+1) + ". " + record.getRecordId() + " - " + record.getItemTitle() + " (User: " + record.getUserId() + ")");
        }
        System.out.print("Enter number (1-" + records.size() + "): "); 
    }
    
    // Mark as damaged/lost menu
    public static void showMarkAsDamagedLostMenu() {
        System.out.println("\nMARK AS DAMAGED/LOST");
        System.out.println(SHORT_LINE);
        System.out.println("1. Damaged (RM25)");
        System.out.println("2. Lost (RM60)");
        System.out.println("0. Available (No fine)");
        System.out.print("Choice: ");
    }
    
    public static void showMarkConfirmation(String conditionMsg) {
        System.out.print("\nConfirm mark as '" + conditionMsg + "'? (y/n): ");
    }
}