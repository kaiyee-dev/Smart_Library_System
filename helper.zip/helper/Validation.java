package helper;

// Validation - Input validation methods
public class Validation {
    
    // Check if username is valid (minimum 3 characters)
    public static boolean validUsername(String username) {
        return username != null && username.length() >= 3;
    }
    
    // Check if password is valid (minimum 6 characters)
    public static boolean validPassword(String password) {
        return password != null && password.length() >= 6;
    }
    
    // Check if email is valid (must contain @ and .)
    public static boolean validEmail(String email) {
        return email != null && email.contains("@") && email.contains(".");
    }
    
    // Check if phone is valid (starts with 0, 10-11 digits)
    public static boolean validPhone(String phone) {
        return phone != null && phone.startsWith("0") && phone.length() >= 10 && phone.length() <= 11;
    }
    
    // Check if role is valid (student, faculty, or staff)
    public static boolean validRole(String role) {
        return role.equals("student") || role.equals("faculty") || role.equals("staff");
    }
    
    // Check if ISBN is not empty
    public static boolean validIsbn(String isbn) {
        return isbn != null && !isbn.isEmpty();
    }
    
    // Check if title is not empty
    public static boolean validTitle(String title) {
        return title != null && !title.isEmpty();
    }
    
    // Check if author is not empty
    public static boolean validAuthor(String author) {
        return author != null && !author.isEmpty();
    }
    
    // Check if genre is not empty
    public static boolean validGenre(String genre) {
        return genre != null && !genre.isEmpty();
    }
    
    // Error messages
    public static String msgUsername() { return "Username must be at least 3 characters!"; }
    public static String msgPassword() { return "Password must be at least 6 characters!"; }
    public static String msgEmail() { return "Invalid email! Example: user@domain.com"; }
    public static String msgPhone() { return "Invalid phone! Must start with 0 and be 10-11 digits"; }
    public static String msgRole() { return "Invalid role! Please enter student, faculty, or staff"; }
    public static String msgIsbn() { return "ISBN cannot be empty!"; }
    public static String msgTitle() { return "Title cannot be empty!"; }
    public static String msgAuthor() { return "Author cannot be empty!"; }
    public static String msgGenre() { return "Genre cannot be empty!"; }
}