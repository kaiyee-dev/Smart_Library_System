package helper;

import java.util.Scanner;

import FineCheck.Fine;
import LibraryItem.LibraryItem;
import Transaction.BorrowRecord;
import User.User;

import java.util.List;

// InputHelper - Handles all user input operations with validation
public class InputHelper {
    
    private static Scanner scanner;
    
    public static void init(Scanner s) {
        scanner = s;
    }
    
    // Get integer input 
    public static int getIntInput() {
        String input = scanner.nextLine();
        if (input == null || input.trim().isEmpty()) {
            System.out.println("invalid input, please try again!");
            return -1;
        }
        
        try {
            return Integer.parseInt(input.trim());
        } catch (Exception e) {
            System.out.println("invalid input, please enter number only!!");
            return -1;
        }
    }

    public static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
        
    }
    
    public static boolean askToContinue(String message) {
        while (true) {
            System.out.print(message + "? (y/n): ");
            String input = scanner.nextLine().toLowerCase();
            if (input.equals("y")) return true;
            if (input.equals("n")) return false;
            System.out.println("Please enter 'y' or 'n'");
        }
    }
    
    // validation with existence check
    
    public static Fine getValidFine(List<Fine> fines) {
        while (true) {
            System.out.print("Fine ID: ");
            String id = scanner.nextLine();
            if (id == null || id.trim().isEmpty()) {
                System.out.println("Error: Fine ID cannot be empty!");
                if (!askToContinue("Try again")) return null;
                continue;
            }
            
            for (Fine f : fines) {
                if (f.getFineId().equalsIgnoreCase(id)) {
                    return f;
                }
            }
            
            System.out.println("Error: Fine ID '" + id + "' not found!");
            if (!askToContinue("Try again")) return null;
        }
    }
    
    public static LibraryItem getValidItem(List<LibraryItem> items) {
        while (true) {
            System.out.print("ISBN: ");
            String isbn = scanner.nextLine();
            if (!Validation.validIsbn(isbn)) {
                System.out.println("Error: " + Validation.msgIsbn());
                if (!askToContinue("Try again")) return null;
                continue;
            }
            
            for (LibraryItem item : items) {
                if (item.getIsbn().equalsIgnoreCase(isbn)) {
                    return item;
                }
            }
            
            System.out.println("Error: ISBN '" + isbn + "' not found!");
            if (!askToContinue("Try again")) return null;
        }
    }
    
    public static User getValidUser(List<User> users) {
        while (true) {
            System.out.print("System ID: ");
            String id = scanner.nextLine();
            if (id == null || id.trim().isEmpty()) {
                System.out.println("Error: System ID cannot be empty!");
                if (!askToContinue("Try again")) return null;
                continue;
            }
            
            for (User user : users) {
                if (user.getUserId().equalsIgnoreCase(id)) {
                    return user;
                }
            }
            
            System.out.println("Error: User ID '" + id + "' not found!");
            if (!askToContinue("Try again")) return null;
        }
    }
    
    public static BorrowRecord getValidRecord(List<BorrowRecord> records) {
        while (true) {
            System.out.print("Record ID: ");
            String id = scanner.nextLine();
            if (id == null || id.trim().isEmpty()) {
                System.out.println("Error: Record ID cannot be empty!");
                if (!askToContinue("Try again")) return null;
                continue;
            }
            
            for (BorrowRecord record : records) {
                if (record.getRecordId().equalsIgnoreCase(id)) {
                    return record;
                }
            }
            
            System.out.println("Error: Record ID '" + id + "' not found!");
            if (!askToContinue("Try again")) return null;
        }
    }
    
    // validation without existence check
    
    public static String getValidIsbnInput() {
        while (true) {
            System.out.print("ISBN: ");
            String isbn = scanner.nextLine();
            if (Validation.validIsbn(isbn)) return isbn;
            System.out.println("Error: " + Validation.msgIsbn());
            if (!askToContinue("Try again")) return null;
        }
    }
    
    public static String getValidTitleInput() {
        while (true) {
            System.out.print("Title: ");
            String title = scanner.nextLine();
            if (Validation.validTitle(title)) return title;
            System.out.println("Error: " + Validation.msgTitle());
            if (!askToContinue("Try again")) return null;
        }
    }
    
    public static String getValidAuthorInput() {
        while (true) {
            System.out.print("Author: ");
            String author = scanner.nextLine();
            if (Validation.validAuthor(author)) return author;
            System.out.println("Error: " + Validation.msgAuthor());
            if (!askToContinue("Try again")) return null;
        }
    }
    
    public static String getValidGenreInput() {
        while (true) {
            System.out.print("Genre: ");
            String genre = scanner.nextLine();
            if (Validation.validGenre(genre)) return genre;
            System.out.println("Error: " + Validation.msgGenre());
            if (!askToContinue("Try again")) return null;
        }
    }
    
    // validation for update with default values
    
    public static String getValidNewTitleWithDefault(String currentTitle) {
        System.out.print("New Title (Enter to keep: " + currentTitle + "): ");
        String input = scanner.nextLine();
        return input.isEmpty() ? currentTitle : input;
    }
    
    public static String getValidNewAuthorWithDefault(String currentAuthor) {
        System.out.print("New Author (Enter to keep: " + currentAuthor + "): ");
        String input = scanner.nextLine();
        return input.isEmpty() ? currentAuthor : input;
    }
    
    public static String getValidNewGenreWithDefault(String currentGenre) {
        System.out.print("New Genre (Enter to keep: " + currentGenre + "): ");
        String input = scanner.nextLine();
        return input.isEmpty() ? currentGenre : input;
    }
    
    // validation for amount and status
    
    public static double getValidAmountWithDefault(double currentAmount) {
        while (true) {
            System.out.print("New Amount (Enter to keep: RM" + String.format("%.2f", currentAmount) + "): ");
            String input = scanner.nextLine();
            if (input.isEmpty()) return currentAmount;
            try {
                double amount = Double.parseDouble(input);
                if (amount >= 0) return amount;
                System.out.println("Error: Amount must be >= 0!");
            } catch (Exception e) {
                System.out.println("Error: Invalid amount! Please enter a number.");
            }
            if (!askToContinue("Try again")) return -1;
        }
    }
    
    public static String getValidPaidStatusWithDefault(String currentStatus) {
        System.out.print("Status (Unpaid/Paid) (Enter to keep: " + currentStatus + "): ");
        String status = scanner.nextLine();
        if (status.isEmpty()) return currentStatus;
        while (!status.equalsIgnoreCase("Unpaid") && !status.equalsIgnoreCase("Paid")) {
            System.out.print("Error: Please enter 'Unpaid' or 'Paid': ");
            status = scanner.nextLine();
        }
        return status;
    }
}