package helper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

// DateUtils - Date operations
public class DateUtils {
    
    private static final DateTimeFormatter FILE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    // Parse date string from user input
    public static LocalDate parseDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) return null;
        try {
            String[] parts = dateStr.trim().split("-");
            if (parts.length == 3) {
                return LocalDate.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            }
        } catch (Exception e) {}
        return null;
    }
    
    // Format date to string
    public static String formatDate(LocalDate date) {
        if (date == null) return "";
        return date.format(FILE_FORMATTER);
    }
    
    // Get current date
    public static LocalDate getCurrentDate() {
        return LocalDate.now();
    }
    
    // Calculate days between two dates
    public static long daysBetween(LocalDate start, LocalDate end) {
        if (start == null || end == null) return 0;
        return ChronoUnit.DAYS.between(start, end);
    }
    
    // Add days to date
    public static LocalDate addDays(LocalDate date, long days) {
        if (date == null) return null;
        return date.plusDays(days);
    }
    
    // Check if due date is overdue
    public static boolean isOverdue(LocalDate dueDate) {
        if (dueDate == null) return false;
        return getCurrentDate().isAfter(dueDate);
    }
    
    // Calculate overdue days
    public static long calculateOverdueDays(LocalDate dueDate) {
        if (!isOverdue(dueDate)) return 0;
        return daysBetween(dueDate, getCurrentDate());
    }
}