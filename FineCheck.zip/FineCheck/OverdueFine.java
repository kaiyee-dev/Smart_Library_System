package FineCheck;

import helper.DateUtils;

// OverdueFine class - extends Fine
public class OverdueFine extends Fine {
    
    private long overdueDays;
    private double ratePerDay;
    
    // Constructor
    public OverdueFine(String fineId, String userId, String borrowRecordId, long overdueDays, double ratePerDay) {
        super(fineId, userId, borrowRecordId, 0, "Overdue");
        this.overdueDays = overdueDays;
        this.ratePerDay = ratePerDay;
        this.amount = calculateAmount();
    }
    
    // Getters
    public long getOverdueDays() { return overdueDays; }
    public double getRatePerDay() { return ratePerDay; }
    
    // Calculate overdue amount
    public double calculateAmount() {
        return overdueDays * ratePerDay;
    }
    
    @Override
    public String getFineType() { return "OverdueFine"; }
    
    // Override toFileString
    @Override
    public String toFileString() {
        return super.toFileString() + String.format("|%d|%.2f", overdueDays, ratePerDay);
    }
    
    // Factory method
    public static OverdueFine fromOverdueFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 9) return null;
        
        OverdueFine fine = new OverdueFine(parts[0], parts[1], parts[2],
                Long.parseLong(parts[7]), Double.parseDouble(parts[8]));
        fine.amount = Double.parseDouble(parts[3]);
        fine.reason = parts[4];
        fine.issuedDate = DateUtils.parseDate(parts[5]);
        fine.status = parts[6];
        return fine;
    }
    
    // toString - calls parent then adds overdueDays and ratePerDay
    @Override
    public String toString() {
        return super.toString() + String.format(" | Days: %d | Rate: RM%.2f", overdueDays, ratePerDay);
    }
}