package FineCheck;

import helper.DateUtils;

import java.io.*;
import java.util.*;

import Transaction.BorrowRecord;
import User.User;

// FineCalculator - Manages fines with full CRUD operations
public class FineCalculator {
    
    private Fine[] fines;
    private String finesFilePath;
    private int nextFineId;
    private int fineCount;
    
    public FineCalculator(String finesFilePath) {
        this.finesFilePath = finesFilePath;
        this.fines = new Fine[100];
        this.nextFineId = 1;
        this.fineCount = 0;
        loadFines();
    }
    
    // CREATE - Add overdue fine
    public boolean createOverdueFine(BorrowRecord record, User user) {
        try {
            if (hasFineForRecord(record.getRecordId())) return false;
            long overdueDays = record.getOverdueDays();
            if (overdueDays <= 0) return false;
            
            String fineId = "FN" + String.format("%04d", nextFineId++);
            OverdueFine fine = new OverdueFine(fineId, user.getUserId(), record.getRecordId(), overdueDays, user.getFineRate());
            
            if (fineCount < fines.length) {
                fines[fineCount++] = fine;
                saveFines();
                System.out.println("Overdue fine calculated: RM" + String.format("%.2f", fine.getAmount()));
                return true;
            }
            return false;
        } catch (Exception e) {
            System.out.println("Error adding overdue fine: " + e.getMessage());
            return false;
        }
    }
    
    // CREATE - Add damage/lost fine
    public boolean createDamageFine(String userId, String recordId, double amount) {
        String fineId = "FN" + String.format("%04d", nextFineId++);
        Fine fine = new Fine(fineId, userId, recordId, amount, "Damage/Lost") {
            @Override
            public String getFineType() { return "DamageFine"; }
        };
        if (fineCount < fines.length) {
            fines[fineCount++] = fine;
            saveFines();
            return true;
        }
        return false;
    }
    
    // READ - Get all fines
    public List<Fine> readAllFines() {
        List<Fine> list = new ArrayList<>();
        for (int i = 0; i < fineCount; i++) list.add(fines[i]);
        return list;
    }
    
    // READ - Find fine by ID
    public Fine readFineById(String fineId) {
        if (fineId == null || fineId.trim().isEmpty()) {
            System.out.println("Fine ID cannot be empty!");
            return null;
        }
        for (int i = 0; i < fineCount; i++) {
            if (fines[i].getFineId().equalsIgnoreCase(fineId)) {
                return fines[i];
            }
        }
        System.out.println("Fine ID: " + fineId + " not found!");
        return null;
    }
    
    // READ - Get fines by user
    public List<Fine> readFinesByUser(String userId) {
        List<Fine> userFines = new ArrayList<>();
        for (int i = 0; i < fineCount; i++) {
            if (fines[i].getUserId().equals(userId)) {
                userFines.add(fines[i]);
            }
        }
        return userFines;
    }
    
    // READ - Get total unpaid fines for user
    public double getTotalUnpaidFines(String userId) {
        double total = 0;
        for (int i = 0; i < fineCount; i++) {
            if (fines[i].getUserId().equals(userId) && fines[i].getStatus().equals("Unpaid")) {
                total += fines[i].getAmount();
            }
        }
        return total;
    }
    
    // READ - Check if user has unpaid fines
    public boolean hasUnpaidFines(String userId) {
        return getTotalUnpaidFines(userId) > 0;
    }
    
    // READ - Get next fine ID
    public int getNextFineId() {
        return nextFineId;
    }
    
    // UPDATE - Update fine
    public boolean updateFine(String fineId, Double newAmount, String newStatus) {
        Fine fine = readFineById(fineId);
        if (fine == null) {
            System.out.println("Fine not found!");
            return false;
        }
        
        if (newAmount != null && newAmount > 0) {
            fine.setAmount(newAmount);
        }
        if (newStatus != null) {
            fine.setStatus(newStatus);
        }
        
        saveFines();
        System.out.println("Fine updated successfully!");
        return true;
    }
    
    // UPDATE - Pay fine
    public boolean payFine(String fineId) {
        Fine fine = readFineById(fineId);
        if (fine == null) {
            System.out.println("Fine not found!");
            return false;
        }
        if (fine.getStatus().equals("Paid")) {
            System.out.println("Fine already paid!");
            return false;
        }
        fine.setStatus("Paid");
        saveFines();
        System.out.println("Fine paid successfully! \nAmount: RM" + String.format("%.2f", fine.getAmount()));
        return true;
    }
    
    // DELETE - Delete fine
    public boolean deleteFine(String fineId) {
        for (int i = 0; i < fineCount; i++) {
            if (fines[i].getFineId().equalsIgnoreCase(fineId)) {
                for (int j = i; j < fineCount - 1; j++) {
                    fines[j] = fines[j + 1];
                }
                fines[--fineCount] = null;
                saveFines();
                System.out.println("Fine deleted successfully!");
                return true;
            }
        }
        System.out.println("Fine ID: " + fineId + " not found!");
        return false;
    }
    
    // VIEW - View user fines
    public void viewUserFines(String userId) {
        List<Fine> userFines = readFinesByUser(userId);
        if (userFines.isEmpty()) {
            System.out.println("No fines found!");
            return;
        }
        
        double totalUnpaid = 0;
        double totalPaid = 0;
        
        System.out.println("\nOVERDUE FINES");
        System.out.println("==================================================================================================");
        System.out.printf("%-10s | %-10s | %-15s | %-10s | %-10s | %-12s\n", "FINE ID", "AMOUNT", "REASON", "STATUS", "DAYS", "PAID DATE");
        System.out.println("==================================================================================================");
        
        for (Fine fine : userFines) {
            if (fine instanceof OverdueFine) {
                OverdueFine of = (OverdueFine) fine;
                String paidDate = fine.getStatus().equals("Paid") ? DateUtils.formatDate(fine.getIssuedDate()) : "-";
                System.out.printf("%-10s | RM%-8.2f | %-15s | %-10s | %-10d | %-12s\n",
                    fine.getFineId(), fine.getAmount(), fine.getReason(), fine.getStatus(), of.getOverdueDays(), paidDate);
                if (fine.getStatus().equals("Unpaid")) {
                    totalUnpaid += fine.getAmount();
                } else {
                    totalPaid += fine.getAmount();
                }
            }
        }
        
        System.out.println("\nDAMAGE/LOST FINES");
        System.out.println("==================================================================================================");
        System.out.printf("%-10s | %-10s | %-15s | %-10s | %-12s\n", "FINE ID", "AMOUNT", "REASON", "STATUS", "PAID DATE");
        System.out.println("==================================================================================================");
        
        for (Fine fine : userFines) {
            if (!(fine instanceof OverdueFine)) {
                String paidDate = fine.getStatus().equals("Paid") ? DateUtils.formatDate(fine.getIssuedDate()) : "-";
                System.out.printf("%-10s | RM%-8.2f | %-15s | %-10s | %-12s\n",
                    fine.getFineId(), fine.getAmount(), fine.getReason(), fine.getStatus(), paidDate);
                if (fine.getStatus().equals("Unpaid")) {
                    totalUnpaid += fine.getAmount();
                } else {
                    totalPaid += fine.getAmount();
                }
            }
        }
        
        System.out.println("==================================================================================================");
        
        if (totalUnpaid > 0) {
            System.out.println("YOU MUST PAY: RM" + String.format("%.2f", totalUnpaid));
        } else {
            System.out.println("[Done] All fines have been paid! Total paid: RM" + String.format("%.2f", totalPaid));
        }
        
        System.out.println("==================================================================================================");
    }
    // PRIVATE - Check if fine exists for record
    private boolean hasFineForRecord(String recordId) {
        for (int i = 0; i < fineCount; i++) {
            if (fines[i].getBorrowRecordId().equals(recordId)) return true;
        }
        return false;
    }
    
    // PRIVATE - Save fines
    private void saveFines() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(finesFilePath))) {
            for (int i = 0; i < fineCount; i++) {
                writer.write((fines[i] instanceof OverdueFine ? ((OverdueFine) fines[i]).toFileString() : fines[i].toFileString()));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving fines: " + e.getMessage());
        }
    }
    
    // PRIVATE - Load fines
    private void loadFines() {
        File file = new File(finesFilePath);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(finesFilePath))) {
            String line;
            while ((line = reader.readLine()) != null && fineCount < fines.length) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    Fine fine = (parts.length >= 9) ? OverdueFine.fromOverdueFileString(line) : Fine.fromFileString(line);
                    if (fine != null) {
                        fines[fineCount++] = fine;
                        int id = Integer.parseInt(fine.getFineId().substring(2));
                        if (id >= nextFineId) nextFineId = id + 1;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading fines: " + e.getMessage());
        }
    }
}