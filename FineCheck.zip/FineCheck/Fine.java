package FineCheck;

import helper.DateUtils;
import java.time.LocalDate;

// Abstract base class for fines
public abstract class Fine {
    
    protected String fineId;
    protected String userId;
    protected String borrowRecordId;
    protected double amount;
    protected String reason;
    protected LocalDate issuedDate;
    protected String status;
    
    // Constructor
    public Fine(String fineId, String userId, String borrowRecordId, double amount, String reason) {
        this.fineId = fineId;
        this.userId = userId;
        this.borrowRecordId = borrowRecordId;
        this.amount = amount;
        this.reason = reason;
        this.issuedDate = DateUtils.getCurrentDate();
        this.status = "Unpaid";
    }
    
    // Getters
    public String getFineId() { return fineId; }
    public String getUserId() { return userId; }
    public String getBorrowRecordId() { return borrowRecordId; }
    public double getAmount() { return amount; }
    public String getReason() { return reason; }
    public LocalDate getIssuedDate() { return issuedDate; }
    public String getStatus() { return status; }
    
    // Setters
    public void setStatus(String status) { this.status = status; }
    public void setAmount(double amount) { this.amount = amount; }
    
    // Check if paid
    public boolean isPaid() { return status.equals("Paid"); }
    
    // Abstract method
    public abstract String getFineType();
    
    // Convert to file format
    public String toFileString() {
        return String.format("%s|%s|%s|%.2f|%s|%s|%s",
                fineId, userId, borrowRecordId, amount, reason, DateUtils.formatDate(issuedDate), status);
    }
    
    // Factory method
    public static Fine fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 7) return null;
        
        if (parts.length >= 9) {
            return OverdueFine.fromOverdueFileString(line);
        }
        
        Fine fine = new Fine(parts[0], parts[1], parts[2], 
                Double.parseDouble(parts[3]), parts[4]) {
            @Override
            public String getFineType() { return "Fine"; }
        };
        fine.issuedDate = DateUtils.parseDate(parts[5]);
        fine.status = parts[6];
        return fine;
    }
    
    // toString - displays all parent fields
    @Override
    public String toString() {
        return String.format("%-10s | %-8s | RM%-8.2f | %-12s | %-8s",
            fineId, userId, amount, reason, status);
    }
}