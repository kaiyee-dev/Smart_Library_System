package LibraryItem;

import java.io.*;
import java.util.*;

// CatalogManager - Manages library items with full CRUD operations
public class CatalogManager {
    
    private LibraryItem[] catalog;
    private String dataFilePath;
    private int itemCount;
    
    public CatalogManager(String dataFilePath) {
        this.catalog = new LibraryItem[200];
        this.dataFilePath = dataFilePath;
        this.itemCount = 0;
        loadCatalog();
    }
    
    // CREATE - Add new item
    public boolean createItem(LibraryItem item) {
        if (readItemByIsbn(item.getIsbn()) != null) {
            System.out.println("Item with ISBN " + item.getIsbn() + " already exists!");
            return false;
        }
        if (itemCount >= catalog.length) {
            System.out.println("Catalog is full!");
            return false;
        }
        catalog[itemCount] = item;
        itemCount++;
        saveCatalog();
        System.out.println("Item added successfully!");
        return true;
    }
    
    // READ - Find item by ISBN
    public LibraryItem readItemByIsbn(String isbn) {
        if (isbn == null || isbn.trim().isEmpty()) {
            return null;
        }
        for (int i = 0; i < itemCount; i++) {
            if (catalog[i].getIsbn().equalsIgnoreCase(isbn)) {
                return catalog[i];
            }
        }
        return null;
    }
    
    // READ - Get all items
    public List<LibraryItem> readAllItems() {
        List<LibraryItem> items = new ArrayList<>();
        for (int i = 0; i < itemCount; i++) {
            items.add(catalog[i]);
        }
        return items;
    }
    
    // READ - Get item count
    public int readItemCount() { return itemCount; }
    
    // READ - Check if available
    public boolean isAvailable(String isbn) {
        LibraryItem item = readItemByIsbn(isbn);
        return item != null && item.getStatus().equals("Available");
    }
    
    // UPDATE - Update item details
    public boolean updateItem(String isbn, String newTitle, String newAuthor, String newGenre, Integer newPageCount) {
        LibraryItem item = readItemByIsbn(isbn);
        if (item == null) {
            System.out.println("Item not found!");
            return false;
        }
        if (newTitle != null && !newTitle.isEmpty()) item.setTitle(newTitle);
        if (newAuthor != null && !newAuthor.isEmpty()) item.setAuthor(newAuthor);
        if (newGenre != null && !newGenre.isEmpty()) item.setGenre(newGenre);
        if (newPageCount != null && newPageCount > 0 && item instanceof Book) {
            ((Book) item).setPageCount(newPageCount);
        }
        saveCatalog();
        System.out.println("Item updated successfully!");
        return true;
    }
    
    // UPDATE - Update item status
    public boolean updateItemStatus(String isbn, String newStatus) {
        LibraryItem item = readItemByIsbn(isbn);
        if (item == null) {
            System.out.println("Item not found!");
            return false;
        }
        item.setStatus(newStatus);
        saveCatalog();
        return true;
    }
    
    // DELETE - Delete item
    public boolean deleteItem(String isbn) {
        for (int i = 0; i < itemCount; i++) {
            if (catalog[i].getIsbn().equalsIgnoreCase(isbn)) {
                for (int j = i; j < itemCount - 1; j++) {
                    catalog[j] = catalog[j + 1];
                }
                catalog[itemCount - 1] = null;
                itemCount--;
                saveCatalog();
                System.out.println("Item deleted successfully!");
                return true;
            }
        }
        System.out.println("Item not found!");
        return false;
    }
    
    // VIEW - Display all items
    public void displayAllItems() {
        if (itemCount == 0) {
            System.out.println("Catalog is empty!");
            return;
        }
        System.out.println("\nCATALOG");
        System.out.println("========================================================================================================================");
        System.out.printf("%-10s | %-35s | %-20s | %-12s | %-10s | %-10s\n", "ISBN", "TITLE", "AUTHOR", "GENRE", "STATUS", "PAGES");
        System.out.println("========================================================================================================================");
        for (int i = 0; i < itemCount; i++) {
            LibraryItem item = catalog[i];
            int pages = (item instanceof Book) ? ((Book) item).getPageCount() : 0;
            System.out.printf("%-10s | %-35s | %-20s | %-12s | %-10s | %-10d\n",
                item.getIsbn(),
                truncate(item.getTitle(), 35),
                truncate(item.getAuthor(), 20),
                truncate(item.getGenre(), 12),
                item.getStatus(),
                pages);
        }
        System.out.println("========================================================================================================================");
    }
    
    // Truncate text
    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 2) + "..";
    }
    
    // Save catalog to file
    private void saveCatalog() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath))) {
            for (int i = 0; i < itemCount; i++) {
                writer.write(catalog[i].toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving catalog: " + e.getMessage());
        }
    }
    
    // Load catalog from file
    private void loadCatalog() {
        File file = new File(dataFilePath);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = reader.readLine()) != null && itemCount < catalog.length) {
                LibraryItem item = LibraryItem.fromFileString(line);
                if (item != null) {
                    catalog[itemCount] = item;
                    itemCount++;
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading catalog: " + e.getMessage());
        }
    }
}