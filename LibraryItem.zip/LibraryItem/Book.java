package LibraryItem;

// Book class - extends LibraryItem
public class Book extends LibraryItem {
    
    private int pageCount;
    
    // Constructor
    public Book(String isbn, String title, String author, String genre, int pageCount) {
        super(isbn, title, author, genre);
        this.pageCount = pageCount;
    }
    
    // Getter and Setter
    public int getPageCount() { return pageCount; }
    public void setPageCount(int pageCount) { this.pageCount = pageCount; }
    
    @Override
    public String getItemType() {
        return "Book";
    }
    
    // Override toFileString to include pageCount
    @Override
    public String toFileString() {
        return super.toFileString() + "|" + pageCount;
    }
    
    // Factory method
    public static Book fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 7) return null;
        
        int pageCount = 0;
        if (parts.length > 7) {
            try {
                pageCount = Integer.parseInt(parts[7]);
            } catch (NumberFormatException e) {
                pageCount = 0;
            }
        }
        return new Book(parts[0], parts[1], parts[2], parts[3], pageCount);
    }
    
    // toString - calls parent then adds pageCount
    @Override
    public String toString() {
        return super.toString() + String.format(" | %-10d", pageCount);
    }
}