package LibraryItem;

import helper.DateUtils;
import java.time.LocalDate;

// Abstract base class for all library items
public abstract class LibraryItem {
    
    private String isbn;
    private String title;
    private String author;
    private String genre;
    private String status;
    private LocalDate addedDate;
    
    // Constructor
    public LibraryItem(String isbn, String title, String author, String genre) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.status = "Available";
        this.addedDate = DateUtils.getCurrentDate();
    }
    
    // Getters
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public String getStatus() { return status; }
    public LocalDate getAddedDate() { return addedDate; }
    
    // Setters
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }
    public void setGenre(String genre) { this.genre = genre; }
    public void setStatus(String status) { this.status = status; }
    
    // Abstract method
    public abstract String getItemType();
    
    // Check if available for borrowing
    public boolean isAvailable() {
        return status.equals("Available");
    }
    
    // Convert to file format
    public String toFileString() {
        return String.format("%s|%s|%s|%s|%s|%s|%s",
                isbn, title, author, genre, status, DateUtils.formatDate(addedDate), getItemType());
    }
    
    // Factory method
    public static LibraryItem fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 7) return null;
        
        LibraryItem item = null;
        if (parts[6].equals("Book")) {
            item = Book.fromFileString(line);
        }
        
        if (item != null) {
            item.status = parts[4];
            item.addedDate = DateUtils.parseDate(parts[5]);
        }
        return item;
    }
    
    // toString - displays all parent fields
    @Override
    public String toString() {
        return String.format("%-10s | %-35s | %-20s | %-12s | %-10s",
            isbn,
            truncate(title, 35),
            truncate(author, 20),
            truncate(genre, 12),
            status);
    }
    
    // Helper method to truncate long text
    protected String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 2) + "..";
    }
}