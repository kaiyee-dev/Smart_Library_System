package Transaction;

// ReturnRecord class - extends Transaction
public class ReturnRecord extends Transaction {
    
    private String borrowRecordId;
    private double damageFine;
    
    // Constructor
    public ReturnRecord(String returnId, String userId, String isbn, String itemTitle, 
                        String borrowRecordId, double damageFine) {
        super(returnId, userId, isbn, itemTitle);
        this.borrowRecordId = borrowRecordId;
        this.damageFine = damageFine;
        this.status = "Completed";
    }
    
    // Getters
    public String getReturnId() { return transactionId; }
    public String getBorrowRecordId() { return borrowRecordId; }
    public double getDamageFine() { return damageFine; }
    
    @Override
    public String getTransactionType() { return "ReturnRecord"; }
    
    // Override toFileString
    @Override
    public String toFileString() {
        return String.format("%s|%s|%s|%s|%s|%.2f|%s",
                transactionId, userId, isbn, itemTitle, borrowRecordId, damageFine, status);
    }
    
    // Factory method
    public static ReturnRecord fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 7) return null;
        
        return new ReturnRecord(parts[0], parts[1], parts[2], parts[3], parts[4], Double.parseDouble(parts[5]));
    }
    
    // toString - calls parent then adds borrowRecordId and damageFine
    @Override
    public String toString() {
        return super.toString() + String.format(" | Borrow ID: %s | Fine: RM%.2f", borrowRecordId, damageFine);
    }
}