package Transaction;

import helper.DateUtils;
import java.time.LocalDate;

// Abstract base class for all transactions
public abstract class Transaction {
    
    protected String transactionId;
    protected String userId;
    protected String isbn;
    protected String itemTitle;
    protected LocalDate transactionDate;
    protected String status;
    
    // Constructor
    public Transaction(String transactionId, String userId, String isbn, String itemTitle) {
        this.transactionId = transactionId;
        this.userId = userId;
        this.isbn = isbn;
        this.itemTitle = itemTitle;
        this.transactionDate = DateUtils.getCurrentDate();
        this.status = "Active";
    }
    
    // Constructor with custom date
    public Transaction(String transactionId, String userId, String isbn, String itemTitle, LocalDate transactionDate) {
        this.transactionId = transactionId;
        this.userId = userId;
        this.isbn = isbn;
        this.itemTitle = itemTitle;
        this.transactionDate = transactionDate;
        this.status = "Active";
    }
    
    // Getters
    public String getTransactionId() { return transactionId; }
    public String getUserId() { return userId; }
    public String getIsbn() { return isbn; }
    public String getItemTitle() { return itemTitle; }
    public LocalDate getTransactionDate() { return transactionDate; }
    public String getStatus() { return status; }
    
    // Setters
    public void setStatus(String status) { this.status = status; }
    
    // Abstract method
    public abstract String getTransactionType();
    
    // Convert to file format
    public String toFileString() {
        return String.format("%s|%s|%s|%s|%s|%s|%s",
                transactionId, userId, isbn, itemTitle, DateUtils.formatDate(transactionDate), status, getTransactionType());
    }
    
    // toString - displays all parent fields
    @Override
    public String toString() {
        return String.format("%-4s | %-4s | %-13s | Date: %-8s",
            transactionId, userId, truncate(itemTitle, 13), DateUtils.formatDate(transactionDate));
    }
    
    // Helper method to truncate long text
    protected String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 2) + "..";
    }
}