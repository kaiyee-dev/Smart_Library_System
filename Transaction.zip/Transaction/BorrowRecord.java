package Transaction;

import helper.DateUtils;
import java.time.LocalDate;

// BorrowRecord class - extends Transaction
public class BorrowRecord extends Transaction {
    
    private LocalDate dueDate;
    private LocalDate returnDate;
    
    // Constructor
    public BorrowRecord(String recordId, String userId, String isbn, String itemTitle, 
                        LocalDate borrowDate, LocalDate dueDate) {
        super(recordId, userId, isbn, itemTitle, borrowDate);
        this.dueDate = dueDate;
        this.returnDate = null;
        this.status = "Borrowed";
    }
    
    // Getters
    public String getRecordId() { return transactionId; }
    public LocalDate getBorrowDate() { return transactionDate; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    
    // Setters
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    
    @Override
    public String getTransactionType() { return "BorrowRecord"; }
    
    // Check if overdue
    public boolean isOverdue() {
        return status.equals("Borrowed") && DateUtils.isOverdue(dueDate);
    }
    
    // Get overdue days
    public long getOverdueDays() {
        return DateUtils.calculateOverdueDays(dueDate);
    }
    
    // Override toFileString
    @Override
    public String toFileString() {
        return String.format("%s|%s|%s|%s|%s|%s|%s|%s",
                transactionId, userId, isbn, itemTitle, 
                DateUtils.formatDate(transactionDate),
                DateUtils.formatDate(dueDate), returnDate == null ? "" : DateUtils.formatDate(returnDate), 
                status);
    }
    
    // Factory method
    public static BorrowRecord fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 8) return null;
        
        BorrowRecord record = new BorrowRecord(parts[0], parts[1], parts[2], parts[3],
                DateUtils.parseDate(parts[4]), DateUtils.parseDate(parts[5]));
        record.returnDate = parts[6].isEmpty() ? null : DateUtils.parseDate(parts[6]);
        record.status = parts[7];
        return record;
    }
    
    // toString 
    @Override
    public String toString() {
        String returnInfo = returnDate == null ? "Not Returned" : DateUtils.formatDate(returnDate);
        String overdueFlag = isOverdue() ? " [OVERDUE]" : "";
        return super.toString() + String.format(" | Due: %s | Return: %-12s | Status: %s%s",
            DateUtils.formatDate(dueDate), returnInfo, status, overdueFlag);
    }
}