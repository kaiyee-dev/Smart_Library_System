package Transaction;

import helper.DateUtils;
import java.io.*;
import java.util.*;

import LibraryItem.CatalogManager;
import LibraryItem.LibraryItem;
import User.User;

import java.time.LocalDate;

// TransactionManager - Manages borrow and return transactions with full CRUD operations
public class TransactionManager {
    
    private BorrowRecord[] borrowRecords;
    private ReturnRecord[] returnRecords;
    private String borrowFilePath;
    private String returnFilePath;
    private CatalogManager catalogManager; 
    private int nextBorrowId;
    private int nextReturnId;
    private int borrowCount;
    private int returnCount;
    
    public TransactionManager(String borrowFilePath, String returnFilePath, CatalogManager catalogManager) {
        this.borrowFilePath = borrowFilePath;
        this.returnFilePath = returnFilePath;
        this.catalogManager = catalogManager;
        this.borrowRecords = new BorrowRecord[500];
        this.returnRecords = new ReturnRecord[500];
        this.nextBorrowId = 1;
        this.nextReturnId = 1;
        this.borrowCount = 0;
        this.returnCount = 0;
        loadBorrowRecords();
        loadReturnRecords();
    }
    
    // CREATE - Borrow item
    public boolean createBorrowRecord(User user, String isbn) {
        if (!user.canBorrow()) {
            System.out.println("You cannot borrow items!");
            return false;
        }
        
        int currentBorrows = getCurrentBorrowCount(user.getUserId());
        if (currentBorrows >= user.getBorrowLimit()) {
            System.out.println("Borrow limit reached! Max: " + user.getBorrowLimit());
            return false;
        }
        
        if (!checkItemAvailability(isbn)) {
            System.out.println("Item is not available!");
            return false;
        }
        
        LibraryItem item = getItemDetails(isbn);
        if (item == null) {
            System.out.println("Item not found!");
            return false;
        }
        
        if (borrowCount >= borrowRecords.length) {
            System.out.println("Borrow record limit reached!");
            return false;
        }
        

        int savedCount = borrowCount;
        
        LocalDate borrowDate = DateUtils.getCurrentDate();
        LocalDate dueDate = DateUtils.addDays(borrowDate, user.getLoanDuration());
        String recordId = "BR" + String.format("%04d", nextBorrowId++);
        
        BorrowRecord record = new BorrowRecord(recordId, user.getUserId(), isbn, item.getTitle(), borrowDate, dueDate);
        borrowRecords[borrowCount] = record;
        borrowCount++;
        
        boolean statusUpdated = catalogManager.updateItemStatus(isbn, "On Loan");
        
        if (!statusUpdated) {
            borrowCount = savedCount;
            borrowRecords[borrowCount] = null;
            System.out.println("Transaction failed. Rolled back.");
            return false;
        }
        
        saveBorrowRecords();
        System.out.println("Item borrowed successfully! Due date: " + DateUtils.formatDate(dueDate));
        return true;
    }
    
    // Helper method to check item availability
    private boolean checkItemAvailability(String isbn) {
        return catalogManager.isAvailable(isbn);
    }
    
    // Helper method to get item details
    private LibraryItem getItemDetails(String isbn) {
        LibraryItem item = catalogManager.readItemByIsbn(isbn);
        if (item == null) {
            System.out.println("Item not found!");
        }
        return item;
    }

    // Helper method to update item status when returned
    private void updateItemReturnStatus(String isbn, double damageFine) {
        if (damageFine == 25.00) {
            catalogManager.updateItemStatus(isbn, "Damaged");
        } else if (damageFine == 60.00) {
            catalogManager.updateItemStatus(isbn, "Lost");
        } else {
            catalogManager.updateItemStatus(isbn, "Available");
        }
    }
    
    // CREATE - Return record
    public boolean createReturnRecord(String borrowRecordId, User user, double damageFine) {
        BorrowRecord record = readBorrowRecordById(borrowRecordId);
        if (record == null) {
            System.out.println("Borrow record not found!");
            return false;
        }
        
        if (record.getStatus().equals("Returned")) {
            System.out.println("Item already returned!");
            return false;
        }
        
        String returnId = "RT" + String.format("%04d", nextReturnId++);
        ReturnRecord returnRecord = new ReturnRecord(returnId, user.getUserId(), record.getIsbn(), 
                record.getItemTitle(), borrowRecordId, damageFine);
        
        if (returnCount < returnRecords.length) {
            returnRecords[returnCount] = returnRecord;
            returnCount++;
            saveReturnRecords();
        }
        
        // Update borrow record
        record.setReturnDate(DateUtils.getCurrentDate());
        record.setStatus("Returned");
        
        // Update item status using helper method
        updateItemReturnStatus(record.getIsbn(), damageFine);
        
        saveBorrowRecords();
        
        if (damageFine > 0) {
            System.out.println("Damage/Lost fine: RM" + String.format("%.2f", damageFine));
        }
        
        return true;
    }
    
    // READ - Find borrow record by ID
    public BorrowRecord readBorrowRecordById(String recordId) {
        if (recordId == null || recordId.trim().isEmpty()) {
            return null;
        }
        for (int i = 0; i < borrowCount; i++) {
            if (borrowRecords[i].getRecordId().equalsIgnoreCase(recordId)) {
                return borrowRecords[i];
            }
        }
        return null;
    }
    
    // READ - Get all borrow records
    public List<BorrowRecord> readAllBorrowRecords() {
        List<BorrowRecord> allRecords = new ArrayList<>();
        for (int i = 0; i < borrowCount; i++) {
            allRecords.add(borrowRecords[i]);
        }
        return allRecords;
    }
    
    // READ - Get user borrow records
    public List<BorrowRecord> readBorrowRecordsByUser(String userId) {
        List<BorrowRecord> userBorrows = new ArrayList<>();
        for (int i = 0; i < borrowCount; i++) {
            if (borrowRecords[i].getUserId().equals(userId)) {
                userBorrows.add(borrowRecords[i]);
            }
        }
        return userBorrows;
    }
    
    // READ - Get active borrow records (not returned)
    public List<BorrowRecord> readActiveBorrowRecords() {
        List<BorrowRecord> active = new ArrayList<>();
        for (int i = 0; i < borrowCount; i++) {
            if (borrowRecords[i].getStatus().equals("Borrowed")) {
                active.add(borrowRecords[i]);
            }
        }
        return active;
    }
    
    // READ - Get all return records
    public List<ReturnRecord> readAllReturnRecords() {
        List<ReturnRecord> allRecords = new ArrayList<>();
        for (int i = 0; i < returnCount; i++) {
            allRecords.add(returnRecords[i]);
        }
        return allRecords;
    }
     
    // DELETE - Delete borrow record
    public boolean deleteBorrowRecord(String recordId) {
        for (int i = 0; i < borrowCount; i++) {
            if (borrowRecords[i].getRecordId().equalsIgnoreCase(recordId)) {
                for (int j = i; j < borrowCount - 1; j++) {
                    borrowRecords[j] = borrowRecords[j + 1];
                }
                borrowRecords[--borrowCount] = null;
                saveBorrowRecords();
                System.out.println("Borrow record deleted!");
                return true;
            }
        }
        System.out.println("Record not found!");
        return false;
    }
    
    // DELETE - Delete return record
    public boolean deleteReturnRecord(String returnId) {
        for (int i = 0; i < returnCount; i++) {
            if (returnRecords[i].getReturnId().equalsIgnoreCase(returnId)) {
                for (int j = i; j < returnCount - 1; j++) {
                    returnRecords[j] = returnRecords[j + 1];
                }
                returnRecords[--returnCount] = null;
                saveReturnRecords();
                System.out.println("Return record deleted!");
                return true;
            }
        }
        System.out.println("Return record not found!");
        return false;
    }
    
    // VIEW - View user borrows
    public void viewUserBorrows(String userId) {
        List<BorrowRecord> userBorrows = readBorrowRecordsByUser(userId);
        if (userBorrows.isEmpty()) {
            System.out.println("No borrow records found!");
            return;
        }
        System.out.println("\nMY BORROWS");
        System.out.println("==================================================================================================");
        System.out.printf("%-10s | %-45s | %-12s | %-12s\n", "RECORD ID", "TITLE", "DUE DATE", "STATUS");
        System.out.println("==================================================================================================");
        for (BorrowRecord record : userBorrows) {
            String status = record.getStatus();
            if (status.equals("Borrowed") && record.isOverdue()) {
                status = "OVERDUE";
            }
            System.out.printf("%-10s | %-45s | %-12s | %-12s\n",
                record.getRecordId(),
                truncate(record.getItemTitle(), 45),
                DateUtils.formatDate(record.getDueDate()),
                status);
        }
        System.out.println("==================================================================================================");
    }
    
    // PRIVATE - Get current borrow count for user
    private int getCurrentBorrowCount(String userId) {
        int count = 0;
        for (int i = 0; i < borrowCount; i++) {
            if (borrowRecords[i].getUserId().equals(userId) && borrowRecords[i].getStatus().equals("Borrowed")) {
                count++;
            }
        }
        return count;
    }
    
    // PRIVATE - Truncate text
    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 2) + "..";
    }
    
    // FILE - Save borrow records
    private void saveBorrowRecords() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(borrowFilePath))) {
            for (int i = 0; i < borrowCount; i++) {
                writer.write(borrowRecords[i].toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving borrow records: " + e.getMessage());
        }
    }
    
    // FILE - Load borrow records
    private void loadBorrowRecords() {
        File file = new File(borrowFilePath);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(borrowFilePath))) {
            String line;
            while ((line = reader.readLine()) != null && borrowCount < borrowRecords.length) {
                BorrowRecord record = BorrowRecord.fromFileString(line);
                if (record != null) {
                    borrowRecords[borrowCount++] = record;
                    int id = Integer.parseInt(record.getRecordId().substring(2));
                    if (id >= nextBorrowId) nextBorrowId = id + 1;
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading borrow records: " + e.getMessage());
        }
    }
    
    // FILE - Save return records
    private void saveReturnRecords() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(returnFilePath))) {
            for (int i = 0; i < returnCount; i++) {
                writer.write(returnRecords[i].toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving return records: " + e.getMessage());
        }
    }
    
    // FILE - Load return records
    private void loadReturnRecords() {
        File file = new File(returnFilePath);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(returnFilePath))) {
            String line;
            while ((line = reader.readLine()) != null && returnCount < returnRecords.length) {
                ReturnRecord record = ReturnRecord.fromFileString(line);
                if (record != null) {
                    returnRecords[returnCount++] = record;
                    int id = Integer.parseInt(record.getReturnId().substring(2));
                    if (id >= nextReturnId) nextReturnId = id + 1;
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading return records: " + e.getMessage());
        }
    }
}