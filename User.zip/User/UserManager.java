package User;

import java.io.*;
import java.util.*;

// UserManager - Manages users with full CRUD operations
public class UserManager {
    
    private User[] users;
    private String dataFilePath;
    private User currentUser;
    private int userCount;
    private int loginAttempts = 0;
    
    public UserManager(String dataFilePath) {
        this.users = new User[100];
        this.dataFilePath = dataFilePath;
        this.currentUser = null;
        this.userCount = 0;
        loadUsers();
    }
    
    // CREATE - Register new user
    public boolean createUser(String userId, String username, String password, String role, 
                              String email, String phone, String field1, String field2) {
        if (readUserById(userId) != null) {
            System.out.println("User ID already exists!");
            return false;
        }
        if (userCount >= users.length) {
            System.out.println("User limit reached!");
            return false;
        }
        
        
        User newUser = null;
        if (role.equals("student")) {
            newUser = new Student(userId, username, password, email, phone, field1, field2);
        } else if (role.equals("faculty")) {
            newUser = new Faculty(userId, username, password, email, phone, field1, field2);
        } else if (role.equals("staff")) {
            newUser = new Staff(userId, username, password, email, phone, field1, field2);
        } else if (role.equals("public")) {
            newUser = new PublicMember(userId, username, password, email, phone, 0);
        }
        users[userCount] = newUser;
        userCount++;
        saveUsers();
        System.out.println("User registered successfully!");
        return true;
    }
    
    // CREATE - Register public member
    public boolean createPublicMember(String userId, String username, String password) {
        if (readUserById(userId) != null) {
            System.out.println("User ID already exists!");
            return false;
        }
        if (userCount >= users.length) {
            System.out.println("User limit reached!");
            return false;
        }
        User newUser = new PublicMember(userId, username, password, null, null, 0);
        users[userCount] = newUser;
        userCount++;
        saveUsers();
        return true;
    }
    
    // READ - Find user by ID
    public User readUserById(String userId) {
        if (userId == null || userId.trim().isEmpty()) {
            return null;
        }
        for (int i = 0; i < userCount; i++) {
            if (users[i].getUserId().equalsIgnoreCase(userId)) {
                return users[i];
            }
        }
        return null;
    }
    
    // READ - Find user by login ID
    public User readUserByLoginId(String loginId) {
        for (int i = 0; i < userCount; i++) {
            String uniqueData = users[i].getUniqueDataForFile();
            String[] parts = uniqueData.split("\\|");
            if (parts.length > 0 && parts[0].equalsIgnoreCase(loginId)) {
                return users[i];
            }
        }
        return null;
    }
    
    // READ - Get all users
    public List<User> readAllUsers() {
        List<User> userList = new ArrayList<>();
        for (int i = 0; i < userCount; i++) {
            userList.add(users[i]);
        }
        return userList;
    }
    
    // READ - Get current logged in user
    public User readCurrentUser() { return currentUser; }
    
    // READ - Check if current user is staff
    public boolean isStaff() { return currentUser != null && currentUser.getRole().equals("Staff"); }
    
    // UPDATE - Update user details
    public boolean updateUser(String systemId, String newUsername, String newEmail, String newPhone, String newPassword,
                            String newMajor, String newDept, String newPos) {
        User user = readUserById(systemId);
        if (user == null) {
            System.out.println("User not found!");
            return false;
        }
        
        if (newUsername != null && !newUsername.isEmpty()) user.setUsername(newUsername);
        if (newEmail != null && !newEmail.isEmpty()) user.setEmail(newEmail);
        if (newPhone != null && !newPhone.isEmpty()) user.setPhone(newPhone);
        if (newPassword != null && !newPassword.isEmpty()) user.setPassword(newPassword);
        
        if (user instanceof Student && newMajor != null && !newMajor.isEmpty()) {
            ((Student) user).setMajor(newMajor);
        } else if (user instanceof Faculty && newDept != null && !newDept.isEmpty()) {
            ((Faculty) user).setDepartment(newDept);
        } else if (user instanceof Staff && newPos != null && !newPos.isEmpty()) {
            ((Staff) user).setPosition(newPos);
        }
        
        saveUsers();
        System.out.println("User updated successfully!");
        return true;
    }
    
    // DELETE - Delete user
    public boolean deleteUser(String systemId) {
        for (int i = 0; i < userCount; i++) {
            if (users[i].getUserId().equalsIgnoreCase(systemId)) {
                if (currentUser != null && currentUser.getUserId().equalsIgnoreCase(systemId)) {
                    System.out.println("You cannot delete your own account!");
                    return false;
                }
                for (int j = i; j < userCount - 1; j++) {
                    users[j] = users[j + 1];
                }
                users[userCount - 1] = null;
                userCount--;
                saveUsers();
                System.out.println("User deleted successfully!");
                return true;
            }
        }
        System.out.println("User not found!");
        return false;
    }
    
    // LOGIN - Login user
    public boolean login(String userId, String password) {
        User user = readUserById(userId);
        if (user == null) {
            user = readUserByLoginId(userId);
        }
        
        if (user != null && user.getPassword().equals(password)) {
            currentUser = user;
            loginAttempts = 0;
            System.out.println("Login successful! Welcome " + user.getUsername());
            return true;
        }
        
        loginAttempts++;
        if (loginAttempts >= 3) {
            System.out.println("Too many failed attempts. Please restart the application.");
            System.exit(1);
        }
        
        System.out.println("Invalid credentials! (" + (3 - loginAttempts) + " attempts left)");
        return false;
    }
    
    // LOGIN - Login as public member
    public void loginAsPublicMember(String publicUserId) {
        for (int i = 0; i < userCount; i++) {
            if (users[i].getUserId().equals(publicUserId)) {
                currentUser = users[i];
                if (users[i] instanceof PublicMember) {
                    PublicMember pm = (PublicMember) users[i];
                    pm.setVisitCount(pm.getVisitCount() + 1);
                    saveUsers();
                }
                System.out.println("\nYou are now browsing as Public Member (View Only Mode)");
                return;
            }
        }
        System.out.println("Error: Public member account not found!");
    }
    
    // LOGOUT - Logout user
    public void logout() {
        currentUser = null;
        System.out.println("Logged out successfully!");
    }
    
    // GENERATE - Generate system ID
    public String generateSystemId(String prefix) {
        int maxNumber = 0;
        for (User user : readAllUsers()) {
            if (user.getUserId().startsWith(prefix)) {
                try {
                    int number = Integer.parseInt(user.getUserId().substring(3));
                    if (number > maxNumber) maxNumber = number;
                } catch (Exception e) {}
            }
        }
        return prefix + String.format("%03d", maxNumber + 1);
    }
    
    // VIEW - Display all users
    public void displayAllUsers() {
        if (userCount == 0) {
            System.out.println("No users registered!");
            return;
        }
        System.out.println("\nUSERS");
        System.out.println("========================================");
        for (int i = 0; i < userCount; i++) {
            System.out.println(users[i].toString());
        }
        System.out.println("========================================");
    }
    
    // Save users to file
    private void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath))) {
            for (int i = 0; i < userCount; i++) {
                writer.write(users[i].toFileString());
                writer.newLine();
            }
            System.out.println("Users saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving users: " + e.getMessage());
        }
    }
    
    // Load users from file
    private void loadUsers() {
        File file = new File(dataFilePath);
        if (!file.exists()) {
            System.out.println("User file not found, will create new one.");
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = reader.readLine()) != null && userCount < users.length) {
                User user = User.fromFileString(line);
                if (user != null) {
                    users[userCount] = user;
                    userCount++;
                }
            }
            System.out.println("Loaded " + userCount + " users from file.");
        } catch (IOException e) {
            System.out.println("Error loading users: " + e.getMessage());
        }
    }
}