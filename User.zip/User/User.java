package User;

// Abstract base class for all user types
public abstract class User {
    
    private String userId;
    private String username;
    private String password;
    private String role;
    private String email;
    private String phone;
    
    // Constructor
    public User(String userId, String username, String password, String role, String email, String phone) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.phone = phone;
    }
    
    // Getters
    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    
    // Setters
    public void setUserId(String userId) { this.userId = userId; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(String role) { this.role = role; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    
    // Abstract methods
    public abstract int getBorrowLimit();
    public abstract int getLoanDuration();
    public abstract double getFineRate();
    public abstract boolean canBorrow();
    public abstract String getUniqueInfo();
    public abstract String getUniqueDataForFile();
    
    // Check if user is staff
    public boolean isStaff() {
        return this.role.equals("Staff");
    }
    
    // Check if user is public member
    public boolean isPublicMember() {
        return this.role.equals("PublicMember");
    }
    
    // Convert to file format
    public String toFileString() {
        String emailStr = email == null ? "" : email;
        String phoneStr = phone == null ? "" : phone;
        return String.format("%s|%s|%s|%s|%s|%s|%s", 
                userId, username, password, role, emailStr, phoneStr, getUniqueDataForFile());
    }
    
    // Factory method
    public static User fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 7) return null;
        
        String userId = parts[0];
        String username = parts[1];
        String password = parts[2];
        String role = parts[3];
        String email = parts[4].isEmpty() ? null : parts[4];
        String phone = parts[5].isEmpty() ? null : parts[5];
        
        // Collect all remaining parts as uniqueData
        StringBuilder uniqueData = new StringBuilder();
        for (int i = 6; i < parts.length; i++) {
            if (i > 6) uniqueData.append("|");
            uniqueData.append(parts[i]);
        }
        
        if (role.equals("Student")) {
            return new Student(userId, username, password, email, phone, uniqueData.toString());
        } else if (role.equals("Faculty")) {
            return new Faculty(userId, username, password, email, phone, uniqueData.toString());
        } else if (role.equals("PublicMember")) {
            return new PublicMember(userId, username, password, email, phone, uniqueData.toString());
        } else if (role.equals("Staff")) {
            return new Staff(userId, username, password, email, phone, uniqueData.toString());
        }
        return null;
    }
    
    // toString - base info for all users
    @Override
    public String toString() {
        String emailStr = (email == null || email.isEmpty()) ? "-" : truncate(email, 20);
        String phoneStr = (phone == null || phone.isEmpty()) ? "-" : phone;
        
        return String.format("%-10s | %-15s | %-10s | %-22s | %-12s",
        userId,truncate(username, 15),role,emailStr,phoneStr);
    }
    
    // Helper method to truncate long text
    protected String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 2) + "..";
    }
}