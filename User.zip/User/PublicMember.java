package User;

// PublicMember class - extends User (view only, cannot borrow)
public class PublicMember extends User {
    
    private int visitCount;
    
    // Constructor for new public member
    public PublicMember(String userId, String username, String password, String email, String phone, int visitCount) {
        super(userId, username, password, "Public", email, phone);
        this.visitCount = visitCount;
    }
    
    // Constructor for loading from file
    public PublicMember(String userId, String username, String password, String email, String phone, String uniqueData) {
        super(userId, username, password, "Public", email, phone);
        int visits = 0;
        try {
            visits = Integer.parseInt(uniqueData);
        } catch (NumberFormatException e) {
            visits = 0;
        }
        this.visitCount = visits;
    }
    
    public int getVisitCount() { return visitCount; }
    public void setVisitCount(int visitCount) { this.visitCount = visitCount; }
    
    @Override
    public int getBorrowLimit() { return 0; }
    @Override
    public int getLoanDuration() { return 0; }
    @Override
    public double getFineRate() { return 0.0; }
    @Override
    public boolean canBorrow() { return false; }
    
    @Override
    public String getUniqueInfo() {
        return String.format("Visits: %d", visitCount);
    }
    
    @Override
    public String getUniqueDataForFile() {
        return String.valueOf(visitCount);
    }
    
    @Override
    public String toString() {
        return super.toString() + String.format(" | %-15s", "Visits: " + visitCount);
    }
}