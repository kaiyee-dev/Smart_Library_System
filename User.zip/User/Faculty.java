package User;

// Faculty class - extends User
public class Faculty extends User {
    
    private String staffId;
    private String department;
    
    // Constructor for new faculty
    public Faculty(String userId, String username, String password, String email, String phone,
                   String staffId, String department) {
        super(userId, username, password, "Faculty", email, phone);
        this.staffId = staffId;
        this.department = department;
    }
    
    // Constructor for loading from file
    public Faculty(String userId, String username, String password, String email, String phone, String uniqueData) {
        super(userId, username, password, "Faculty", email, phone);
        String[] parts = uniqueData.split("\\|");
        this.staffId = parts.length > 0 ? parts[0] : "";
        this.department = parts.length > 1 ? parts[1] : "";
    }
    
    public String getStaffId() { return staffId; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    
    @Override
    public int getBorrowLimit() { return 5; } // borrow book limit
    @Override
    public int getLoanDuration() { return 10; } // loan day
    @Override
    public double getFineRate() { return 0.20; }
    @Override
    public boolean canBorrow() { return true; }
    
    @Override
    public String getUniqueInfo() {
        return String.format("Login ID: %s | Dept: %s", staffId, department);
    }
    
    @Override
    public String getUniqueDataForFile() {
        return String.format("%s|%s", staffId, department);
    }
    
    @Override
    public String toString() {
        String deptStr = (department == null || department.isEmpty()) ? "-" : department;
        return super.toString() + String.format(" | %-15s | %-18s", staffId, truncate(deptStr, 20));
    }
}