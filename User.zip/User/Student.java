package User;

// Student class - extends User
public class Student extends User {
    
    private String studentId;
    private String major;
    
    // Constructor for new student

    
    public Student(String userId, String username, String password, String email, String phone,
                   String studentId, String major) {
        super(userId, username, password, "Student", email, phone);
        this.studentId = studentId;
        this.major = major;
    }
    
    // Constructor for loading from file
    public Student(String userId, String username, String password, String email, String phone, String uniqueData) {
        super(userId, username, password, "Student", email, phone);
        String[] parts = uniqueData.split("\\|");
        this.studentId = parts.length > 0 ? parts[0] : "";
        this.major = parts.length > 1 ? parts[1] : "";
    }
    
    public String getStudentId() { return studentId; }
    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }
    
    @Override
    public int getBorrowLimit() { return 3; } 
    @Override
    public int getLoanDuration() { return 7; }
    @Override
    public double getFineRate() { return 0.50; }
    @Override
    public boolean canBorrow() { return true; }
    
    @Override
    public String getUniqueInfo() {
        return String.format("Login ID: %s | Major: %s", studentId, major);
    }
    
    @Override
    public String getUniqueDataForFile() {
        return String.format("%s|%s", studentId, major);
    }
    
    @Override
    public String toString() {
        String majorStr = (major == null || major.isEmpty()) ? "-" : major;
        return super.toString() + String.format(" | %-15s | %-18s", studentId, truncate(majorStr, 20));
    }
}