package User;

// Staff class - extends User
public class Staff extends User {
    
    private String staffId;
    private String position;
    
    // Constructor for new staff
    public Staff(String userId, String username, String password, String email, String phone,
                 String staffId, String position) {
        super(userId, username, password, "Staff", email, phone);
        this.staffId = staffId;
        this.position = position;
    }
    
    // Constructor for loading from file
    public Staff(String userId, String username, String password, String email, String phone, String uniqueData) {
        super(userId, username, password, "Staff", email, phone);
        String[] parts = uniqueData.split("\\|");
        this.staffId = parts.length > 0 ? parts[0] : "";
        this.position = parts.length > 1 ? parts[1] : "";
    }
    
    public String getStaffId() { return staffId; }
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    
    @Override
    public int getBorrowLimit() { return 15; }
    @Override
    public int getLoanDuration() { return 45; }
    @Override
    public double getFineRate() { return 0.10; }
    @Override
    public boolean canBorrow() { return true; }
    
    @Override
    public String getUniqueInfo() {
        return String.format("Login ID: %s | Position: %s", staffId, position);
    }
    
    @Override
    public String getUniqueDataForFile() {
        return String.format("%s|%s", staffId, position);
    }
    
    @Override
    public String toString() {
        String posStr = (position == null || position.isEmpty()) ? "-" : position;
        return super.toString() + String.format(" | %-15s | %-18s", staffId, truncate(posStr, 20));
    }
}